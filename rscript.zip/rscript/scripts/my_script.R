my_function <- function(x) {
  return(x)
}